class Name:
   #constructor method - instantiation
   def __init__(self, first, middle, last):
      self.first = first
      self.middle = middle
      self.last = last

aName = Name('Mary','Elizabeth','Smith')