from newton import *

print("Enter a number: ")
number = int(input())
print(sqrt(number))
print(average(144,9))