def square(number):
   squared = number * number
   return squared

print(square(2))
print("Squared (defined in square function): " + str(squared))