#numbers = [1,2,3]
#it = iter(numbers)
#print(next(it))
#print(next(it))
#print(next(it))
fileIt = open('grades.txt', 'r')
print(next(fileIt), end='')
